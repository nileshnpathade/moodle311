<?php
	require_once(dirname(__FILE__) . '/../../config.php');
	$courseid = optional_param('courseid', '', PARAM_INT);
	$groupid = optional_param('groupname', '', PARAM_INT);
	$id = optional_param('id', -1, PARAM_INT);
	global $DB, $USER, $CFG;
	
	$systemcontext = context_system::instance();
	//get the admin layout
	$PAGE->set_pagelayout('admin');
	$PAGE->set_context($systemcontext);
	$course = array();
	require_login();
	$PAGE->set_url('/local/reports/activityreport.php');
	$PAGE->set_title('Activity Reports');
	//Header and the navigation bar
	$PAGE->set_heading('Activity Reports');
	$PAGE->navbar->add('Activity Reports');

	if(!empty($courseid) && $courseid != ''){
		$course = $DB->get_record('course', array('id' => $courseid));
		$PAGE->navbar->add($course->fullname, '/course/view.php?id='.$course->id);
	}

	echo $OUTPUT->header();
	echo '<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>';
	echo '<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
	<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<script src="//cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
	<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
	<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>';

 	$line = array();
	$coursemodules = array();
	if(!empty($course->id)){
		$where = "  "; 
		$sqlgroup = " ";
		if(!empty($groupid) ){
			$sqlgroup = " 
				JOIN {groups} AS g ON g.courseid = c.id
				JOIN {groups_members} AS m ON g.id = m.groupid and m.userid = u.id";
			$where .= " AND g.id = ".$groupid; 
		}
	 	$sql = "SELECT u.id, u.firstname, u.lastname,c.id as courseid, u.username, u.email FROM {user} u
				INNER JOIN {role_assignments} ra ON ra.userid = u.id
				INNER JOIN {context} ct ON ct.id = ra.contextid
				INNER JOIN {course} c ON c.id = ct.instanceid
				INNER JOIN {role} r ON r.id = ra.roleid
				INNER JOIN {course_categories} cc ON cc.id = c.category
				$sqlgroup
				WHERE r.id = 5 and c.id =? $where";



		$userdetails = $DB->get_records_sql($sql, array($course->id));

		foreach($userdetails as $user){
				$line[] = $user->firstname. " " . $user->lastname;	
				
				$course_modules = get_array_of_activities($user->courseid);
				//print_object($course_modules);
				$completiondates = $DB->get_record_sql("SELECT timecompleted FROM {course_completions} WHERE course = ? AND userid = ? ", array($course->id, $user->id));
				$timecompleted = 0;
				if(!empty($completiondates->timecompleted)){
					$timecompleted = date('d/m/Y',  $completiondates->timecompleted);
				}
				$i = 0;  $line = array('');
				foreach ($course_modules as $key => $cm) {
						if(isset($cm->completion) && !empty($cm->completion)){
							$results = $DB->get_records_sql("SELECT * FROM {course_modules_completion} as cmc 
															INNER JOIN {user} as u ON u.id = cmc.userid 
															WHERE userid = ? AND coursemoduleid = ? ", array($user->id, $cm->cm));	
							
							$resultstatus = 'Not Completed';
							if(!empty($results)){
								$resultstatus = 'Completed';
							}

							$coursemodules[$i] = $cm->name;
							$line[0] = $user->firstname. " " . $user->lastname;
							$line[1] = $user->username;
							$line[2] = $user->email;
							$line[3] =  $timecompleted;
							$line[$i] = $resultstatus;
						}
						$i = $i + 4;
					}
					$data[] = $line;
				 }
}

//exit();
	echo "<div  style='padding: 0px 15px;'> <h4> Course: ".$course->fullname." </h4> </div>";
?>
	<style type="text/css">
		table.dataTable thead th {
				vertical-align: middle;
		}
	</style>


	<div id="completion_report_wrapper" class="dataTables_wrapper no-footer">

	<div>
		<form action="activityreport.php" name="filter" id="filter" method="POST">
			<label>Select Course: </label>
			<select name="courseid" class="form-control" style="width: 25% !important;" onchange="activityreport(this.value)">
				<option> Select course </option>
				<?php 
					$courses = get_courses();
					foreach($courses as $course){
				?>
					<option value="<?php echo $course->id; ?>"> <?php echo $course->fullname; ?></option>
				<?php } ?>
			</select>
			<br>
			<label>Select Group: </label>
			<select name="groupname" class="form-control" style="width: 25% !important;" id="groups">
				<option> Select Group </option>
				<?php 
					// $groups = $DB->get_records_sql('SELECT * FROM mdl_groups', array());
					// foreach($groups as $group){
				?>
					<!-- <option value="<?php // echo $group->id; ?>"> <?php // echo $group->name; ?></option> -->
				<?php // } ?>
			</select>
			<br>
			<input type="submit" name="submit" value="Filter" class="btn btn-primary">
		</form>
	</div>
	<br>
	<table class="generaltable dataTable no-footer" id="completion_report" width="100%" role="grid" aria-describedby="completion_report_info" style="width: 100%;">
		<thead>
			<tr>
				<th> Users </th>
				<th> Username </th>
				<th> Email </th>
				<th> Completion Date</th>
				<?php
					foreach($coursemodules as $modules){
						echo "<th> $modules </th>";
					}
				?>
			</tr>
		</thead>
		<tbody>
		<?php 
		foreach($data as $datarows){
			echo "<tr>";
				$j = 0;
				foreach($datarows as $datarow){						
					echo "<td>".$datarow."</td>"; 
					$j++;
				}
			echo "</tr>";
			}
		?>
		</tbody>
	</table>
</div>
	<?php
echo $OUTPUT->footer();
echo html_writer::script(
"$('#completion_report').DataTable( {
    dom: 'Bfrtip',
   	buttons: [
        'csv', 'excel'
    ]
} )"
);

echo html_writer::script('
	function activityreport(courseid){
		//alert(courseid);
		$.ajax({
			type: "POST",
			url: "ajax_activityreport.php?courseid="+courseid,
			success: function(data){
				//alert(data);
				$("#groups").html(data);
			}
		});
	}
');
