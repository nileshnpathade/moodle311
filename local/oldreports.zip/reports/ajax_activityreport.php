<?php
	require_once(dirname(__FILE__) . '/../../config.php');
	$courseid = optional_param('courseid', '', PARAM_INT);
	global $DB, $USER, $CFG;
	
	$systemcontext = context_system::instance();
	//get the admin layout
	$PAGE->set_pagelayout('admin');
	$PAGE->set_context($systemcontext);
	$course = array();
	require_login();

$groups = $DB->get_records('groups', array('courseid' => $courseid));
?>
<option> Select Group </option>
<?php
	foreach ($groups as $key => $group) { ?>
	<option value="<?php echo $group->name; ?>"> <?php echo $group->name; ?>  </option>
<?php }